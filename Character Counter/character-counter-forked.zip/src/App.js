import { useState } from "react";
import "./styles.css";

export default function App() {
  var [msg, setMsg] = useState("");

  var changeHandler = (event) => {
    let val = event.target.value;
    if (val.length > 50) {
      let msgToBeShown =
        "no. of chars has exceeded the limit by " + (val.length - 50);
      setMsg(msgToBeShown);
    } else {
      let msgToBeShown = "no. of chars is within the word limit";
      setMsg(msgToBeShown);
    }
  };

  return (
    <div className="App">
      <h3>Word limit is 50 chars</h3>
      <input
        onChange={changeHandler}
        style={{ height: "150px", width: "400px" }}
      />
      <h2>{msg}</h2>
    </div>
  );
}
